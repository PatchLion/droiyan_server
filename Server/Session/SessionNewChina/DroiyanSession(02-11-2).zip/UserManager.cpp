///////////////////////////////////////////////////////////////////////////////
// User Manager Class 
#include "StdAfx.h"
#include "Usermanager.h"

CUserManager::CUserManager()
{
}

CUserManager::~CUserManager()
{
}

