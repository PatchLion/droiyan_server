///////////////////////////////////////////////////////////////////////////////
// User Manager Class 
#include "StdAfx.h"
#include "UserServermanager.h"

CUserServerManager::CUserServerManager()
{
}

CUserServerManager::~CUserServerManager()
{
}

