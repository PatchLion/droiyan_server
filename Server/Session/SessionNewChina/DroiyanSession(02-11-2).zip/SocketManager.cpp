///////////////////////////////////////////////////////////////////////////////
// Socket Manager Class 
#include "StdAfx.h"
#include "Socketmanager.h"

CSocketManager::CSocketManager()
{
}

CSocketManager::~CSocketManager()
{
}

