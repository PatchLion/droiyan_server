///////////////////////////////////////////////////////////////////////////////
// PROTOCOL DEFINE
//
#ifndef __PROTOCOL_H

#define NB_LOGIN_REQ				((BYTE)0x10)
#define NB_LOGIN_RESULT				((BYTE)0x11)

#endif

